/**
 * KFR (http://kfrlib.com)
 * Copyright (C) 2016  D Levin
 * See LICENSE.txt for details
 */

#include <kfr/graphics/geometry.hpp>

namespace kfr
{
inline namespace CMT_ARCH_NAME
{

}
} // namespace kfr