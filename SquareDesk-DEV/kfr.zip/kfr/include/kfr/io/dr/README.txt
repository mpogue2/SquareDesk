Code for reading/writing wav and reading flac and mp3 files.

These 3 files are released to public domain by the author:
dr_flac.h
dr_wav.h
dr_mp3.h

See also information in these files.

https://github.com/mackron/dr_libs
