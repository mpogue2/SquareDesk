# How to do Sample Rate Conversion


[See also a gallery with results of applying various SRC presets](src_gallery.md)