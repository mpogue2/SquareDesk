# How to apply a Biquad filter

[See also a gallery with results of applying various Biquad filters](bq_gallery.md)
