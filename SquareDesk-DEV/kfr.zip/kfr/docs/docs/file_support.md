# File types support

## Reading

* wav: 16-,24-,32-bit signed, 32-,64-bit IEEE
* wav W64: 16-,24-,32-bit signed, 32-,64-bit IEEE
* flac

## Writing

* wav: 16-,24-,32-bit signed, 32-,64-bit IEEE
* wav W64: 16-,24-,32-bit signed, 32-,64-bit IEEE
