
# Scatter Circulate

From Parallel Two-Faced
Lines and other applicable 2 x 4 formations (such as Facing
Lines, Back-to-Back Lines, and some T-Bones):
Ends [Split Circulate](../b1/circulate.md)
as those facing out of the center Box
[Crossover Circulate](../a1/cross_over_circulate.md)
as those facing into the center Box do a
Crossover Circulate within that Box.
Parallel Two-Faced Lines end in Parallel Waves.

> 
> ![alt](scatter_circulate-1.png)
> ![alt](scatter_circulate-2.png)
> 

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
