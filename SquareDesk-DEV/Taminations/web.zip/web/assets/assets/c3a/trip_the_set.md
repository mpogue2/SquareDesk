
# Trip the Set
**Parts:** 2  

From Parallel Lines with the
Ends Back-To-Back, or other applicable formations:
Ends [Cross Fold](../ms/fold.md)
and [Roll](../plus/anything_and_roll.md)
as Centers ([Concentric](../c1/concentric_concept.md))
[1/4 Out](../a1/quarter_in.md) and [Trade](../b2/trade.md).
Parallel Lines end in Facing Lines.

> 
> ![alt](trip_the_set-1.png)
> ![alt](trip_the_set-2.png)
> 

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
