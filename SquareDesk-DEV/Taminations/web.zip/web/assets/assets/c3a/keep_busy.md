# Keep Busy

**Parts for Trailers:** 4  

From Parallel Two-Faced Lines:
Leaders [Couples Circulate](../b1/circulate.md)
[With The Flow](../c1/with_the_flow.md)
as Trailers ***[1/2 Circulate](../b1/circulate.md)***,
***Very Centers [Hinge](../ms/hinge.md)***,
***[Flip The Diamond](../plus/flip_the_diamond.md)***,
***[Step & Fold](../c1/step_and_fold.md)***.
Ends in Parallel Waves.

> 
> ![alt](keep_busy-1.png)
> ![alt](keep_busy-2.png)
> 

### Teaching Notes
Unlike Mini Busy, where the Leaders turn
individually, in Keep Busy they start moving together as a Couple.
But for the original Trailers, this is just Mini Busy followed by
Step and Fold.

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
