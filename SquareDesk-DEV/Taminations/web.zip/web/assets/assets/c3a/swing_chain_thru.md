
# Swing Chain Thru
**Parts:** 4  

From Parallel Waves, Eight
Chain Thru, or other applicable formations:
***All Arm Turn 1/2***;
***Centers Cast Off 1/4***;
***Very Centers [Trade](../b2/trade.md)***;
***Centers Cast Off 1/4***.
Ends in Parallel Waves.

> 
> ![alt](swing_chain_thru-1.png)
> ![alt](swing_chain_thru-2.png)
> 

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
