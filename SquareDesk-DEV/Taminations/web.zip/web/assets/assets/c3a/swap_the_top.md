
# Swap the Top

From Facing Couples: Belles [Extend](../b2/extend.md) (to left hands) and
[Cast Off 3/4](../ms/cast_off_three_quarters.md)
as Beaus [Run](../b2/run.md) (to their right)
once and a half. Ends in a R-H Wave.

> 
> ![alt](swap_the_top-1.png)
> ![alt](swap_the_top-2.png)
> 

A **Reverse Swap the Top** is the mirror image of this: Beaus
Extend (to right hands) and Cast Off 3/4 as Belles Run (to their
left) once and a half. Ends in a L-H Wave.

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
