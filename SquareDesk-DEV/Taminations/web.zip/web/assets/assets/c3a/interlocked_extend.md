
# Interlocked Extend 

From a 1/4 Line only: In one smooth motion,
As Couples Extend and each Line Slither.
Ends in Parallel Waves.

>
> ![alt](interlocked_extend-1.png)
> ![alt](interlocked_extend-2.png)
>

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.