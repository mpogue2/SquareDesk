
# Peel Chain Thru

From Trade By or 3/4 Tag:
centers Arm Turn 1/2 (stepping to a wave if necessary) and [Slip](../a2/slip.md)
as outsides [Cast Back](../c1/cast_back.md) and
Touch 1/2; Centers of each side
[Cast Off 3/4](../ms/cast_off_three_quarters.md) as others do
their part of [Fan The Top](../plus/fan_the_top.md).
A Trade By or R-H 3/4 Tag ends in Parallel R-H Waves;
a L-H 3/4 Tag ends in a Parallelogram.

> 
> ![alt](peel_chain_thru-1.png)
> ![alt](peel_chain_thru-2.png)
> ![alt](peel_chain_thru-3.png)
> 

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
