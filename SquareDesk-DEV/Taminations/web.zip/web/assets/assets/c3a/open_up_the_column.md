# Open Up

## Open Up the Column

From Columns: #1 dancers [Trail Off](../a2/trail_off.md) and
[Roll](../plus/anything_and_roll.md)
as #2 dancers [Circulate](../b1/circulate.md),
[Peel Off](../plus/peel_off.md)
and [Roll](../plus/anything_and_roll.md)
as #3 and #4 dancers [Circulate](../b1/circulate.md) and
Centers [Cast Off 3/4](../ms/cast_off_three_quarters.md);
all [Extend](../b2/extend.md).
Ends in Parallel Waves.

> 
> ![alt](open_up-1.png)
> ![alt](open_up-2.png)
> 

## Open Up and \<anything>

From Columns or other applicable formations: #1 dancers Trail Off and
Roll as #2 dancers Circulate, Peel Off and Roll as the other dancers
walk forward to form a Box (or other compact formation) in the center
and do the \<anything> call. 

> 
> ![alt](open_up-3.png)
> ![alt](open_up-4.png)
> 

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
