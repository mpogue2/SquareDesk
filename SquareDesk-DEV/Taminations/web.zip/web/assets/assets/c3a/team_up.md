
# Team Up

From any applicable formation (for example, Lines Facing Out,
Trade By, Inverted Lines):
Ends 1/2 [Circulate](../b1/circulate.md)
and [Hinge](../ms/hinge.md) as Centers (working in the
Center) do a Beaus [Run](../b2/run.md) as Belles Dodge.
If all the Centers are Beaus, they all Run (flip over to their right);
if all the Centers are Belles, they all Dodge (slide over to their left).
Lines Facing Out or Trade By ends in Columns.

> 
> ![alt](team_up-1.png)
> ![alt](team_up-2.png)  
> ![alt](team_up-3.png)
> ![alt](team_up-4.png)
> 

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
