
# Catch \<anything> 1, 2, 3, 4

**Parts:** 3  

From applicable formations: Square Thru the given number of hands to a Wave;
do the \<anything> call; Step and Fold.

> 
> ![alt](catch-1.png)
> ![alt](catch-2.png)
> ![alt](catch-3.png)
> ![alt](catch-4.png)
> 

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
