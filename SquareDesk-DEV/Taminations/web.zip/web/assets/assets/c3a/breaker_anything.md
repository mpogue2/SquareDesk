
# Breaker

## Breaker 1,2,3

From Columns, Magic Columns, or applicable T-Bone 2x4s: Ends Cast Off
3/4 as Centers Box Counter Rotate 1/4 and 1/2 Box Circulate; 
Center Wave (or Line) Cast Off the given number of quarters
(for example, for Breaker 3, Cast Off 3/4)
as the others move up (Phantom Hourglass Circulate). From Columns,
Breaker 1 or 3 ends in Ocean Waves; Breaker 2 ends in Facing Diamonds.

> 
> ![alt](breaker-1.png)
> ![alt](breaker-2.png)
> ![alt](breaker-3.png)
> 

## Breaker <anything>

From Columns, Magic Columns, or applicable T-Bone 2x4s: Ends Cast Off
3/4 as Centers Box Counter Rotate 1/4 and 1/2 Box Circulate; Center
Wave (or Line) does the
\<anything> call as the others move up (Phantom Hourglass
Circulate). Usually ends in Parallel Lines, Twin Diamonds, or an
Hourglass depending upon the \<anything> call.

> 
> ![alt](breaker-4.png)
> ![alt](breaker-5.png)
> 

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
