
# Recoil
**Parts:** 2  

From an applicable Non-T-Bone 2 x 2:
***[Box Recycle](../c1/recycle.md)***;
***[Step & Fold](../c1/step_and_fold.md)***.
Ends in a Mini-Wave Box.

> 
> ![alt](recoil-1.png)
> ![alt](recoil-2.png)
> ![alt](recoil-3.png)
>

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
