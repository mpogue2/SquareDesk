
# Mini Chase

From Back-to-Back Couples or an
applicable 2 x 2 T-Bone (all Leaders):
Belles [Shakedown](../c1/shakedown.md)
as Beaus [Partner Tag](../a1/partner_tag.md).
Back-to-Back Couples end in a R-H Mini-Wave Box.

> 
> ![alt](mini_chase-1.png)
> ![alt](mini_chase-2.png)
> 

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
