
# Triple Play

From Columns: #1 dancers [Transfer](../a1/transfer_the_column.md)
([Trail Off](../a2/trail_off.md),
[Circulate](../b1/circulate.md),
[1/4 In](../a1/quarter_in.md)) as others
1/2 [Circulate](../b1/circulate.md) and
[Trade](../b2/trade.md); in the new Center Columns #1
dancers [Transfer](../a2/box_transfer.md)
([Trail Off](../a2/trail_off.md) &
[Roll](../plus/anything_and_roll.md)) as the others 1/2
[Circulate](../b1/circulate.md) and
[Hinge](../ms/hinge.md);
all [Extend](../b2/extend.md).
Ends in Parallel Waves.

>
> ![alt](triple_play-1.png)
> ![alt](triple_play-2.png)
> ![alt](triple_play-3.png)
> ![alt](triple_play-4.png)
> 

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
