
# 1/4 (or 3/4) Mix

**Parts:** 3  

From a R-H Mini-Wave Box, a Diamond with the Centers in a R-H Mini-Wave,
or other applicable formations:
***Those who can, [Right Arm Turn 1/4](../b1/allemande.md) (or 3/4)***;
in the resulting Line or Wave the ***centers [Cross Run](../b2/run.md)***;
then ***the new centers [Trade](../b2/trade.md)***.
Ends in a Line or Wave.

> 
> ![alt](1_4_mix-1.png)
> ![alt](1_4_mix-2.png)
> 

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
