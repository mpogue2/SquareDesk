
# Snap the Lock

From Parallel Lines:
***[Partner Tag](../a1/partner_tag.md)***;
***Outsides [Partner Tag](../a1/partner_tag.md)
as Centers Touch***,
***[Lock It](../a1/lock_it.md)***,
***Step Thru***.
Ends in Back-to-Back Lines.

> 
> ![alt](snap_the_lock-1.png)
> ![alt](snap_the_lock-2.png)
> ![alt](snap_the_lock-3.png)
> 

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
