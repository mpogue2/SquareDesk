# Latch On (\<fraction>)

**Parts:** 2

From a General Tandem (Column of 2):
Right Roll to a Wave; Arm Turn \<fraction> (default 1/4).
Ends in a R-H Mini-Wave.

> 
> ![alt](latch_on-1.png)
> ![alt](latch_on-2.png)
> ![alt](latch_on-3.png)
> 

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
