
# The Pulley

## The Pulley
**Parts:** 2  

From a 1/4 Box: Triple Cross; Peel Off. Ends in Parallel Two-Faced Lines.

## Spin the Pulley
**Parts:** 3  

From a Static Square (or from the
formation obtained from a Static Set after Heads Step into the
Center) or from a Wave between and perpendicular to Facing Couples:
***Centers or those designated Arm Turn 3/4***
(stepping to a wave if necessary);
***all [Triple Cross](../a1/triple_cross.md)***;
***all [Peel Off](../plus/peel_off.md)***.
Ends in Parallel Two-Faced Lines.

> 
> ![alt](spin_the_pulley-1.png)
> ![alt](spin_the_pulley-2.png)
> ![alt](spin_the_pulley-3.png)
> ![alt](spin_the_pulley-4.png)
> 

## (Spin) The Pulley But \<anything>

(Spin) The Pulley, but replace the Peel Off with the \<anything> call.

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
