
# Stable \<anything>
**CONCEPT**   

Do the given call without changing your facing direction.
Your ending position will be the same as if you had executed
the call normally, but your facing direction will not change
from your original facing direction.

> 
> ![alt](stable_concept-1.png)
> ![alt](stable_concept-2.png)  
> ![alt](stable_concept-3.png)
> ![alt](stable_concept-4.png)
> 

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
