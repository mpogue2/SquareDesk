
# Reach Out

From a Mini-Wave Box, Tandem
Couples, or applicable 2 x 2 T-Bones:
Trailers 1/2 [Box Circulate](../b1/circulate.md)
and Phantom Run outward (Reverse Flip)
as Leaders [Box Circulate](../b1/circulate.md) once and a half.
A Mini-Wave Box ends in
a Wave; a 2 x 2 T-Bone usually ends in a Diamond; Tandem
Couples ends in a One-Faced Line.

> 
> ![alt](reach_out-1.png)
> ![alt](reach_out-2.png)
> 

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
