
# Scoot the Diamond
**Parts:** 3

From a Single 1/4 Tag:
[Scoot Back](../ms/scoot_back.md);
Outsides 1/4 to the handhold;
all [Diamond Circulate](../plus/diamond_circulate.md).
Ends in a Diamond.

> 
> ![alt](scoot_the_diamond-1.png)
> ![alt](scoot_the_diamond-2.png)
> 

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
