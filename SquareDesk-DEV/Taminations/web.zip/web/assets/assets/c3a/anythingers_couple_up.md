
# \<anything>er's Couple Up

**Parts:** 2  

From any applicable formation: 
Do the \<anything> call, then the Leaders U-Turn Back.
If the \<anything> is a type of Circulate or Counter Rotate,
it may be abbreviated in the same way as for the 
"[anything concept](../c2/anything_concept.md)" [C-2],
for example. "Inroll Couple Up" or "Split Counter Couple Up".

> 
> ![alt](anythingers_couple_up-1.png)
> ![alt](anythingers_couple_up-2.png)  
>
> ![alt](anythingers_couple_up-3.png)
> ![alt](anythingers_couple_up-4.png)
> 

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
