
# Spin Chain the Line

From a Tidal Wave,
Facing Lines, or other applicable formations:
All Arm Turn 1/2; Centers of each side
[Cast Off 3/4](../ms/cast_off_three_quarters.md) and
[Spread](../plus/anything_and_spread.md)
as Very Centers [Trade](../b2/trade.md); Very Ends and Very
Centers slide together and
[Cast Off 3/4](../ms/cast_off_three_quarters.md) to finish in the center.
Ends in Parallel Lines.

> 
> ![alt](spin_chain_the_line-1.png)
> ![alt](spin_chain_the_line-2.png)
> ![alt](spin_chain_the_line-3.png)
> ![alt](spin_chain_the_line-4.png)
> 

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
