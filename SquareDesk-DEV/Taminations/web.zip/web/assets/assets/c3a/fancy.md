
# Fancy

## Fancy

From Columns: ***Trailers (#2 and #4 dancers)
[Press Out](../c1/press.md)***;
***Trailing Couples [1/2 Press Ahead](../c1/press.md)***;
***Outsides work Phantom: all
[Turn & Deal](../a1/turn_and_deal.md)***
or Left Turn and Deal, depending on the handedness of the Column.
Ends in a Double Pass Thru.

> 
> ![alt](fancy-1.png)
> ![alt](fancy-2.png)
> ![alt](fancy-3.png)
> 
 
## Scoot and Fancy

**Parts:** 2  

From Columns: Triple Scoot; Fancy.

> 
> ![alt](fancy-4.png)
> ![alt](fancy-5.png)
> ![alt](fancy-6.png)
> 
###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.

<!-- Parts
Fancy1
Fancy2
Fancy3
-->