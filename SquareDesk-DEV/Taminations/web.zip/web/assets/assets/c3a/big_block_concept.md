
# Big Block <anything>

**CONCEPT**   

From Interlocked Blocks, Butterfly, “O”, or other applicable
formations in a 4x4 matrix (for example, Leaders Press Ahead from Two-Faced
Lines): Execute the given call working in distorted Parallel Lines,
and ending with each dancer occupying one of the footprints of the
original formation.

> 
> ![alt](big_block-1.png)
> ![alt](big_block-2.png)
> 
> ![alt](big_block-3.png)
> ![alt](big_block-4.png)
> 
> ![alt](big_block-5.png)
> ![alt](big_block-6.png)
> 

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
