
# 1/4 (or 3/4) the Deucey

From Parallel Waves.

## 1/4 the Deucey

***[Arm Turn](../b1/allemande.md) 1/4***;
***Centers [Cast Off 1/4](../ms/cast_off_three_quarters.md)
as the Lead Ends [Circulate](../b1/circulate.md)
and the Trailings End 1/2 [Circulate](../b1/circulate.md)***;
***[Center Star turns 1/4](../b1/star.md)***;
***those who meet (Center Wave) Cast
Off 1/4 as the other Centers move up*** (Phantom
[Hourglass Circulate](../a2/hourglass_circulate.md))
to become the Ends of a Wave. Ends in Parallel
Waves.

> 
> ![alt](1_4_the_deucey-1.png)
> ![alt](1_4_the_deucey-2.png)
> ![alt](1_4_the_deucey-3.png)
> ![alt](1_4_the_deucey-4.png)
> 

## 3/4 the Deucey

Same as 1/4 the Deucey except each of the four 1/4 turns 
is replaced with a 3/4 turn. Ends in Parallel Waves.

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
