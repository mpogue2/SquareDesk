
# Trade the Deucey

From Parallel Lines, Twin Diamonds, a Generalized Thar,
or other applicable formations:
Centers [Trade](../b2/trade.md)
and [Spread](../plus/anything_and_spread.md)
as the Ends [Cross Over Circulate](../a1/cross_over_circulate.md).
Parallel Lines end in Parallel Lines,
Twin Diamonds end in Point-to-Point Diamonds.

> 
> ![alt](trade_the_deucey-1.png)
> ![alt](trade_the_deucey-2.png)  
> ![alt](trade_the_deucey-3.png)
> ![alt](trade_the_deucey-4.png)
> 

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
