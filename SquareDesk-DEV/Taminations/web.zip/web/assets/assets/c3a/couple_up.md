
# Couple Up

**Parts:** 2

From any applicable 2x2: Box Circulate;
Leaders U-Turn Back (toward the Center of the 2x2). Ends in a 2x2.

> 
> ![alt](couple_up-1.png)
> ![alt](couple_up-2.png)
> 

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
