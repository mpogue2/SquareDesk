
# Chase the (\<fraction>) Tag

From Back-to-Back Couples only:
In one smooth motion, Belles U-Turn Back to the right
and all Vertical (\<fraction>) Tag.

Note: This is a tagging call and may be used as part
of any tagging call combination, such as Chase Back or Chase Chain Thru.
In addition, the calls Chase Your ((Criss) Cross) Neighbor
introduced at C-1 and C-2 are considered to be instances of
“\<tag> Your ((Criss) Cross) Neighbor” at C-3A
and are thus defined as “Chase the 1/2 Tag;
Follow / Cross / Criss Cross Your Neighbor”.

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
