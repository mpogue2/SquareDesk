
# Strip the Diamond / Hourglass

From Twin Diamonds or an Hourglass:
Outside four 1/2 [Zoom](../b2/zoom.md) and
[Trade](../b2/trade.md) as the Very Centers
[Cast Off 3/4](../ms/cast_off_three_quarters.md)
as the Other Centers
[Counter Rotate](../c1/counter_rotate.md) 1/4 on the outside to end
as the Very Outside dancers.
Strip The Diamond ends in a Tidal Line.
Strip the Hourglass ends in two Lines of 3
with a perpendicular Mini-Wave between them.

>
> ![alt](strip_the_diamond-1.png)
> ![alt](strip_the_diamond-2.png)  
> ![alt](strip_the_diamond-3.png)
> ![alt](strip_the_diamond-4.png)
>

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
