
# 1/4 (or 3/4) Wheel the Ocean / Sea

**Parts:** 2  

## 1/4 Wheel the Ocean / Sea

From a L-H Two-Faced Line:Left Cast 1/4 (1/2 Wheel Around, 
ending in Facing Couples);
Finish Wheel the Ocean/Sea.
(Ocean: Belles diagonally R-H Pull By; Sea:
Belles Walk as Beaus Dodge.) Ends in a Mini-Wave Box. 
(Ocean: R-H Box; Sea: LH Box.)

> 
> ![alt](1_4_wheel-1.png)
> ![alt](1_4_wheel-2.png)
> ![alt](1_4_wheel-3.png)
>

## 3/4 Wheel the Ocean / Sea

From a R-H Two-Faced Line: Left Cast 3/4 (Wheel Around 1 1/2, ending in Facing
Couples); Finish Wheel the Ocean/Sea. Ends in a Mini-Wave Box

>
> ![alt](3_4_wheel-1.png)
> ![alt](3_4_wheel-2.png)
> ![alt](3_4_wheel-3.png)
>

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
