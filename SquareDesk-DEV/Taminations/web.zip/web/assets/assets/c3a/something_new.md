
# Something New

From Columns: #1 and #2 dancers [Couple Up](../c3a/couple_up.md)
as #3 dancers 1/2 [Circulate](../b1/circulate.md)
and [U-Turn Back](../b1/turn_back.md)
as #4 dancers [Circulate](../b1/circulate.md) and Veer Out.
Ends in a 1/4 Tag.

> 
> ![alt](something_new-1.png)
> ![alt](something_new-2.png)
> 

Alternative definition: First Two Couple Up as the Last
Two Circulate and the Leader inwardly (Right or Left) Roll To A Wave.

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
