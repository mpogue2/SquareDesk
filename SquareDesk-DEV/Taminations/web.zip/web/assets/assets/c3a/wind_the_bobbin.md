
# Wind The Bobbin

From Columns: Leaders Peel Off (becoming Ends of lines) as
Trailers 1/2 Circulate; new Ends Circulate twice as new Centers Cast
Off 3/4, Very Centers Trade, and Cast Off 3/4. Ends in Parallel
Waves.

> 
> ![alt](wind_the_bobbin-1.png)
> ![alt](wind_the_bobbin-2.png)
> 

### Teaching Notes
The first part is like the first part of Peel the Top. 
The remaining parts for the original Trailers
are like the last three parts of Spin Chain Thru.

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
