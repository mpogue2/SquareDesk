
# Explode the Top

From Parallel Lines: Explode; End Beaus Circulate once and a
half as End Belles Circulate, Veer inward, and U-Turn Back as Centers
Touch 1/2 and the Very Centers Cast Off 3/4 while the other Centers
Step Ahead, all joining to form a R-H Star; turn the Star 1/4, the
new Very Ends Unwrap the Star (those dancers walk forward as everyone
else follows), and all Face In to end in Facing Lines. Note: The
amount of the star turn is sometimes modified, typically using words
like "turn the star 1/4 more than usual".

> 
> ![alt](explode_the_top-1.png)
> ![alt](explode_the_top-2.png)
> ![alt](explode_the_top-3.png)
> ![alt](explode_the_top-4.png)
> ![alt](explode_the_top-5.png)
> 
> 
### Teaching Notes

After the initial explode, the new Ends can think of their part as Pass Thru,
Ends Bend, and put your right hand in to form a star
(which will involve either stepping ahead a bit further
or turning a bit further).
The new Centers effectively Spin the Top, except that the person
who would move around to the end of the wave instead walks straight ahead,
raising his or her hand to indicate that he or she will be leading
the Unwrap. After the other dancers have adjusted their positions
to make Stars, the Stars are turned one position, after which
the leader unwraps the Star straight ahead and all adjust
to make Facing Lines.

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
