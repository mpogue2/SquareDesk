
# Stampede
**Parts for Centers: 3;  Parts for Ends: 2**

From a 3/4 Tag or other applicable formations:
Centers [Trade The Wave](../plus/trade_the_wave.md),
[Hinge](../ms/hinge.md), and
[Cross](../a1/anything_and_cross.md) (Trailers diagonal
Pull By using the outside hand) as the Ends
[Cross Cast Back](../c1/cast_back.md) and
[Pass In](../a1/pass_in.md).
A 3/4 Tag ends in an Eight Chain Thru.

> 
> ![alt](stampede-1.png)
> ![alt](stampede-2.png)
> 
###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
