
# Like a Couple Up


From any applicable formation: Do the last part of a Couple Up (that is,
Leaders U-Turn Back). So the examples illustrated above under
"\<anything> er’s Couple Up" could alternatively be
expressed as "Split Trade Circulate Like a Couple Up" and "Split
Transfer Like a Couple Up".

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
