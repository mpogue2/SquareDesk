
# Slant

## Slant Touch and Wheel

From Two-Faced Lines: Trailers Veer inward to form Facing
Couples and Touch, as Leaders do their part of a Wheel And Deal. Ends
in a 1/4 Tag.

> 
> ![alt](slant_touch_and_wheel-1.png)
> ![alt](slant_touch_and_wheel-2.png)
>

## Slant \<anything> By \<anything>

From Parallel Two-Faced Lines and other applicable formations:
Trailers Veer inward to form Facing Couples and do
the first \<anything> call (working in the center) as Leaders
do their part of the second \<anything> call.

>
> ![alt](slant_anything_by_anything-1.png)
> ![alt](slant_anything_by_anything-2.png)
> 

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
