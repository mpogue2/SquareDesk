
# Link Up

From Parallel Two-Faced Lines or Promenade (where those
designated act as Leaders): Leaders Cast Off 1/4 using the Outside
dancer as the pivot point, Roll, and Press Ahead, as the Trailers 1/2
Circulate and Crossfire. Ends in Parallel Waves.

> 
> ![alt](link_up-1.png)
> ![alt](link_up-2.png)
> 
###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
