
# Finally \<concept> \<anything>

**META-CONCEPT**   

Do the \<anything> call applying the given \<concept>
only to the last part of the call.

> 
> ![alt](finally-1.png)
> ![alt](finally-2.png)
> ![alt](finally-3.png)  
> ![alt](finally-4.png)
> ![alt](finally-5.png)
> ![alt](finally-6.png)  
> ![alt](finally-7.png)
> ![alt](finally-8.png)
> ![alt](finally-9.png)
> 

###### @ Copyright 2004-2024 Vic Ceder and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
