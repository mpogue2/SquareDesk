
# Running Bear

Here is the sequence starting with the heads.  Typically heads start twice
and sides start twice.  
 
1. Four ladies chain 
1. Four ladies chain 
1. Rollaway 
1. Heads star thru 
1. Dive thru 
1. (Centers) Pass thru 
1. Dosado 
1. Circle Four Half 
1. Dive thru 
1. Centers square thru while others divide and star thru 
1. Dosado 
1. Circle four half 
1. Dive thru 
1. (Centers) Box the gnat and Pull thru   Then swing your corner, promenade. 
