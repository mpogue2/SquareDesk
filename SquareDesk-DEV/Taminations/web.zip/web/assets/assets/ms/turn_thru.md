
# Turn Thru

### Starting formation

Facing Dancers

### Command examples

#### Turn Thru
#### Swing Thru; Turn Thru
#### Girls Turn Thru
#### Squared set: Heads Turn Thru; Separate, Around 1 To A Line
#### Heads Square Thru 4; Spin The Top; Turn Thru; Courtesy Turn
### Dance action

In one smooth motion, dancers Step To A Wave (but use forearm styling), Right Arm Turn
1/2, and Step Thru.

### Ending formation

Back-To-Back Dancers

### Timing

4

### Styling

Similar to Allemande Left. Use normal forearm position. Men's free hand in natural dance
position. Woman's skirt work desirable for free hand.

### Comments

The [Ocean Wave Rule](../b2/ocean_wave_rule.md) applies to this call.

Turn Thru is always a 180 degree turn.
From an Alamo Ring, if the desired action is to get everyone
to their corners, the proper call would be an Arm Turn, not a Turn Thru.

###### @ Copyright 1994, 2000-2020 by CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
