
# Grand Spin

Also called Grand Colonel Spin.  Typically danced to the
Colonel Bogey March.  The heads and sides dance the same moves, just
different orders for the two sequences.



**Heads**  
{high:Part1}Star Thru{/high}  
{high:Part2}Spin the Top{/high}  
{high:Part3}Star Thru{/high}  
{high:Part4}California Twirl and Face{/high}  
  
{high:Part5}Back up 3 steps and Face In{/high}  
{high:Part6}Go Forward and Dosado{/high}  
{high:Part7}Star Thru{/high}  
  
{high:Part8}Star Thru{/high}  
{high:Part9}Spin the Top{/high}  
{high:Part10}Star Thru{/high}  
{high:Part11}California Twirl and Face{/high}  
  
{high:Part12}Back up 3 steps and Face In{/high}  
{high:Part13}Go Forward and Dosado{/high}  
{high:Part14}Star Thru{/high}  
  


**Sides**  
Back up 3 steps and Face In  
Go Forward and Dosado  
Star Thru  
  
Star Thru  
Spin the Top  
Star Thru  
California Twirl and Face  
  
Back up 3 steps and Face In  
Go Forward and Dosado  
Star Thru  
  
Star Thru  
Spin the Top  
Star Thru  
California Twirl and Face  
  



