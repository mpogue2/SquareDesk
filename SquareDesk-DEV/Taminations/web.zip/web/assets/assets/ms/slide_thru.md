
# Slide Thru

### Starting formation

Facing Dancers

### Command example

#### Slide Thru

### Dance action

In a single smooth motion, Pass Thru and Men Face Right, Women Face Left.

### Ending formation

If two men, Right-Hand Mini-Wave; if two women, Left-Hand Mini-Wave;
otherwise, a Couple.

### Timing

4

### Styling

Arms in natural dance position with skirt work optional for the women.
Hands should be rejoined in the appropriate position
(Couple or Hands Up handhold) for the next call.

The turn can be blended with the Pass Thru
to finish with a sliding or dodging motion.

### Comment

The [Ocean Wave Rule](../b2/ocean_wave_rule.md) applies to this call.

###### @ Copyright 1994, 2000-2020 by CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
