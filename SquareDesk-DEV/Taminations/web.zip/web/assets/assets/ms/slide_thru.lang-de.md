
# Slide Thru

### Startformation

Facing Dancers

### Kommandobeispiele

#### Slide Thru

### Tanzaktion

In einer durchgängigen, flüssigen Bewegung: Pass Thru und Männer Face Right (1/4-Drehung nach
rechts), Frauen Face Left (1/4-Drehung nach links).

### Schlussformation

Bei zwei Männern: Right-Hand Mini-Wave; bei zwei Frauen: Left-Hand Mini-Wave; ansonsten:
Couple.

### Timing

4

### Styling

Die Arme bleiben in natürlicher Tanzposition, wobei „Skirt Work“ für Frauen optional ist. Die Hände
sollten in einer für den nächsten Call angemessenen Position (Couple oder Hands Up Handhaltung) wieder
gefasst werden

Die Drehung kann mit dem Pass Thru verschmolzen werden um das Kommando mit einer gleitenden
Bewegung abzuschließen.

### Bemerkungen

Die [Ocean Wave Rule](../b2/ocean_wave_rule.md) gilt für dieses Kommando.

###### @ Copyright 1994, 2000-2019 by CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
