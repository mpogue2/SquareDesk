
# Hinge Family

Hinge ist ein halber Trade von benachbarten Tänzern. Nachfolgend sind die zwei Mainstream Versionen von
Hinge aufgeführt.

## Single Hinge

### Startformation

nur Mini-Wave

### Kommandobeispiele

#### Single Hinge
#### Hinge
#### Couples Circulate; Centers Hinge
#### Heads Pass The Ocean; Extend; Split Circulate; Girls Cast Off 3/4; Boys Hinge

### Tanzaktion

1/2 Trade

### Schlussformation

Mini-Wave

### Timing

2

### Styling

Die Tänzer behalten ihre Handverbindung bei.

### Bemerkungen

"Hinge 1/4" ist unzulässig, da Hinge, im Gegensatz zu Touch 1/4, nicht in Brüche aufgeteilt wird.

Partner Hinge (Startformation: nur Couple) wurde 1988 aus dem Mainstream Programm entfernt. Das
Kommando "Hinge" kann sowohl für Single Hinge als auch für Partner Hinge verwendet werden, letzteres ist
im Mainstream jedoch unzulässig.

## Couples Hinge

### Startformation
nur One-Faced Line und Two-Faced Line

### Kommandobeispiele

#### Couples Hinge

### Tanzaktion

1/2 Couples Trade

### Schlussformation

Two-Faced Line

### Timing

3

### Styling

Jedes Paar behält seine Handverbindungen bei.

### Bemerkungen

Aus einer Grand One-Faced Line, endet Couples Hinge in Right-Hand Two-Faced Lines (d.h.
aneinander ausgerichtet und nicht offset).

###### @ Copyright 1994, 2000-2019 by CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.

