
# Slip the Clutch

### Startformation

Thar in Bewegung, Wrong Way Thar in Bewegung

### Kommandobeispiele

#### Slip The Clutch, Allemande Left
#### Slip The Clutch, Skip One, Left Allemande
#### Slip The Clutch, Skip One, Skip Another, Skip Another, Turn Partner Left, Four Ladies Chain
#### (Aus einem Wrong Way Thar) Slip The Clutch, Pass Two, Right And Left Grand

### Tanzaktion

Jede Rückwärtsbewegung wird beendet und die Armverbindung zwischen den äußeren Tänzern und
den benachbarten Centern wird gelöst. Alle Tänzer bewegen sich vorwärts, um das Zentrum des Sets herum,
zum nächsten Tänzer

Bei dem Kommando Skip One (oder Pass One) oder einer anderen Anzahl, bewegen sich alle auf ihrer
Kreisbahn weiter vorwärts und gehen an der angegebenen Anzahl Tänzer vorbei.

### Schlussformation

Thar, Wrong Way Thar

### Timing

2

### Styling

Obwohl es eine Änderung der Bewegungsrichtung ist, können die Tänzer im Center den
Bewegungswechsel fließend und bequem gestalten, indem sie die Armverbindung einfach lösen und die gleiche
Hand für das nächste Kommando bereit halten. Die Handhaltung nach einem Slip The Clutch hängt vom
nächsten Kommando ab.

Die Tänzer im Center behalten ihren Stern in der Regel bei.

### Bemerkungen

Die [Facing Couples Rule](../b2/facing_couples_rule.md) gilt für dieses Kommando nicht.

###### @ Copyright 1994, 2000-2019 by CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
