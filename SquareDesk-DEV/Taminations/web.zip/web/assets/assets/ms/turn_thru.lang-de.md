
# Turn Thru

### Startformation

Facing Dancers

### Kommandobeispiele

#### Turn Thru
#### Swing Thru; Turn Thru
#### Girls Turn Thru
#### Squared set: Heads Turn Thru; Separate, Around 1 To A Line
#### Heads Square Thru 4; Spin The Top; Turn Thru; Courtesy Turn
### Tanzaktion

In einer flüssigen Bewegung tanzen die Tänzer ein Step To A Wave (verwenden jedoch UnterarmStyling), Right Arm Turn 1/2 und Step Thru.

### Schlussformation

Back-To-Back Dancers

### Timing

4

### Styling

Ähnlich wie bei Allemande Left. Die normale Unterarmposition wird angewendet. Männer halten ihre
freie Hand in natürlicher Tanzposition. Bei Frauen ist Skirt Work mit der freien Hand wünschenswert.

### Comments

Die [Ocean Wave Rule](../b2/ocean_wave_rule.md) gilt für dieses Kommando.

Turn Thru ist immer eine 180 Grad Drehung. Wenn man aus einem Alamo-Ring jeden zu seinem Corner
bringen möchte, wäre das korrekte Kommando ein Arm Turn, kein Turn Thru.

###### @ Copyright 1994, 2000-2019 by CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
