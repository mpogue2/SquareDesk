
# Recycle (nur aus Ocean Waves)

### Startformation

Nur aus Ocean Waves

### Kommandobeispiele

#### Recycle

### Tanzaktion

Ends tanzen ein Cross Fold. Währenddessen führt jeder Center einen Fold hinter seinen
benachbarten End-Tänzer aus, folgt diesem und richtet sich anschließend so aus, dass man am Ende
nebeneinander in einer Facing Couples Formation steht.

### Schlussformation

Facing Couples

### Timing

4

### Styling

Wenn jeder End-Tänzer und der benachbarte Center-Tänzer sich zu drehen beginnen, lösen sie ihre MiniWave-Handhaltung auf. Sobald die Tänzer annähernd in die gleiche Richtung schauen, nehmen sie ein Couple Handhold ein.

### Bemerkungen

Die [Facing Couples Rule](../b2/facing_couples_rule.md) gilt für dieses Kommando nicht. Aus Facing Couples hat das Kommando
„Recycle“ eine andere Definition, die nicht Bestandteil des Mainstream Programms ist.

Beim Unterrichten kann es hilfreich sein, die Aktion der Centers als „Fold, follow, face“ („Fold“, folgen, jemanden anschauen) zu veranschaulichen und zu erklären, dass die Centers sich annähernd einmal im Kreis drehen und am Ende, nur ein kleines Stück weiter hinten von der Position wo sie gestartet sind, neben dem Tänzer dem sie gefolgt sind, stehen.

###### @ Copyright 1994, 2000-2019 by CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
