
# Shoot The Star

### Startformation

Thar in Bewegung, Wrong Way Thar in Bewegung

### Kommandobeispiele

(Die ersten fünf Kommandobeispiele beginnen aus einem Thar mit den Männern als
Centers)
#### Shoot The Star; Right And Left Grand
#### Shoot The Star To Another Thar, Go Forward 2, Men Swing In To A Backup Star
#### Shoot The Star Go All The Way Around, Give Corner Right, Men Swing In To A Wrong Way Thar
#### Shoot The Star A Full Turn, Go Backwards 3, Right, Left, Right, Boys Wheel In To A Wrong Way Thar
#### Shoot The Star A Full Turn, This Way Go Forward 3, Right, Left, Right; Allemande Left
#### (Aus einem Wrong Way Thar) Shoot The Star, Go Forward 2, With A Left And Right, To Another Wrong Way Thar

### Tanzaktion

Die Tänzer im Center lösen die innere Handverbindung die den Stern geformt hat und führen mit
dem benachbarten äußeren Tänzern einen „Arm Turn 1/2 and Step Thru“ durch. Wurde „Full around“
angegeben, dann ist der Arm Turn eine volle Drehung (360 Grad).

### Schlussformation

Right and Left Grand Circle

### Timing

4; Full Around: 6

### Styling

Eine Unterarmverbindung wird für den Arm Turn verwendet. Die andere Hand nimmt eine natürliche
Tanzposition ein und ist für das nächste Kommando bereitzuhalten. Frauen können während des Arm Turn
damit fortfahren ihren Rock dekorativ einzusetzen.

### Bemerkungen

Die [Facing Couples Rule](../b2/facing_couples_rule.md) gilt für dieses Kommando nicht.

Nach Shoot the Star, gibt der Caller manchmal die Anweisung, dass die Tänzer einen oder weitere Pull-ByKommandos mit anschließendem Arm Turn in einen neuen Thar ausführen sollen. In dem zweiten oben
aufgeführten Kommandobeispiel, folgt nach den Step Thru ein Right Pull By, die Tänzer gehen weiter
vorwärts in eine linke Unterarmverbindung und führen einen Left Arm Turn 1/2 aus.

Der Caller kann die Tänzer anweisen, eine bestimmte Anzahl an Händen weiter zu gehen. Jede Hand ist ein
Pull By, mit Ausnahme der letzten Hand, die normalerweise der Beginn des Arm Turn in einen Thar oder
Wrong Way Thar ist.

Einige Caller sagen „Forward“ und meinen damit in normale „Right and Left Grand“ Richtung und benutzen
„Backward“ (oder „Back“ oder „Backwards“) für die entgegengesetzte Richtung. Andere Caller sagen „Forward“
und meinen damit die Richtung in die man gerade schaut und benutzen die Worte „Back“ oder „Backward“
niemals. Beides ist akzeptabel, aber Caller müssen darauf achten, die Tänzer nicht zu verwirren. Siehe dazu
das vierte und fünfte oben aufgeführte Kommandobeispiel.

Einige Caller benutzen einen Shoot the Star in einer Weise, dass er als Cast Off 3/4 in einen Alamo Ring endet,
z.B. „Shoot The Star 3/4 To An Alamo Ring“ oder einfach „Shoot The Star To An Alamo Ring“. Shoot the Star
kann auch in das nächste Kommando integriert werden, z. B. "Shoot The Star, 4 Ladies Chain".

###### @ Copyright 1994, 2000-2019 by CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
