
# Centers In

### Startformation
Completed Double Pass Thru, Eight Chain Thru. Allgemeiner ausgedrückt, ein Paar mit dem
Rücken zur Mitte des Sets, wobei jeder Center direkt auf einen äußeren Tänzer schaut.

### Kommandobeispiele

#### Centers In
#### Put Centers In

### Tanzaktion

Ohne die Blickrichtung zu verändern, bewegen sich die äußeren Tänzer seitwärts voneinander weg,
um Platz für die Centers zu schaffen die vorwärts gehen und zwischen den äußeren Tänzer enden.

### Schlussformation

Verschieden. Aus einer Completed Double Pass Thru Formation, Lines Facing Out. Aus einer
Eight Chain Thru Formation, Inverted Lines mit sich anschauenden End-Tänzern.

### Timing

2

### Styling

Wenn die Tänzer aus der Mitte zwischen die äußeren Tänzer treten, gehen sie mit diesen eine
angemessene Handverbindung ein (Couples Handhold wenn sie in die gleiche Richtung schauen oder Ocean
Wave Styling wenn sie in entgegengesetzte Richtungen schauen).

### Bemerkungen

Während Centers In zusätzlichen Platz in der Mitte zu schaffen scheint, wird dieser Platz
entweder durch das nächste Kommando oder durch Square Breathing (siehe "Zusätzliche Angaben:
Tanzaktion: Square Breathing") wieder verringert oder beseitigt.

###### @ Copyright 1994, 2000-2019 by CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
