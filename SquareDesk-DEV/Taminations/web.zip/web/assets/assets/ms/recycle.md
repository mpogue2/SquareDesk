
# Recycle

### Starting formation

Ocean Wave only

### Command example

#### Recycle

### Dance action

Ends Cross Fold. Meanwhile, each Center Folds behind the adjacent End and follows the End
around, adjusting to finish side-by-side in Facing Couples.

### Ending formation

Facing Couples

### Timing

4

### Styling

As each End and adjacent Center begin to turn, they release their mini-wave handhold. They smoothly
establish a couple handhold once they are approximately facing the same direction.

### Comments

The [Facing Couples Rule](../b2/facing_couples_rule.md) does not apply.
From Facing Couples, the call Recycle has a different
definition that is not part of the Mainstream program.

When teaching it may be helpful to prompt the action of the Centers
as "Fold, follow, face" and to explain that
the Centers walk almost a full circle to finish
a small step back from where they started and beside the dancer
they followed.

###### @ Copyright 1994, 2000-2020 by CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
