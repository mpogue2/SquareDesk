
# Pass to the Center

### Startformation

Eight Chain Thru

### Kommandobeispiele

Pass To The Center

### Tanzaktion

Pass Thru. Diejenigen die danach aus dem Square herausschauen, Partner Trade

### Schlussformation

Double Pass Thru

### Timing

Tänzer die im Center enden: 2. Tänzer die außen enden: 6.

### Styling

Dasselbe Styling wie bei Pass Thru und Partner Trade.

### Comments

Die [Ocean Wave Rule](../b2/ocean_wave_rule.md) gilt für dieses Kommando.

Durch den Pass Thru sollen einige Tänzer in die Mitte kommen und die anderen Tänzer sollen nach außen
gehen. Aus Facing Lines ist dieses Kommando nicht zulässig. 

Dieses Kommando ist aus Left-Hand Ocean Waves nicht zulässig. Siehe
[Pass Thru](../b1/pass_thru.md).

###### @ Copyright 1994, 2000-2019 by CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
