
# Pass to the Center

### Starting formation

Eight Chain Thru

### Command example

Pass To The Center

### Dance action

Pass Thru. Those looking out of the square Partner Trade.

### Ending formation

Double Pass Thru

### Timing

Dancers who finish in the center: 2. Dancers who finish on the ends: 6.

### Styling

Same styling as Pass Thru and Partner Trade.

### Comments

The [Ocean Wave Rule](../b2/ocean_wave_rule.md) applies to this call.

On the Pass Thru, some dancers should be coming into the center
and other dancers should be heading towards the outside.
This call is not proper from Facing Lines.

This call is not proper from Left-Hand Ocean Waves.
See [Pass Thru](../b1/pass_thru.md).

###### @ Copyright 1994, 2000-2020 by CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
