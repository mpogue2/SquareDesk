
# Flutterwheel / Reverse Flutterwheel

### Startformation

Facing Couples

### Kommandobeispiele

#### Flutterwheel
#### Reverse Flutterwheel
#### Reverse The Flutter

### Tanzaktion

Die Tänzer auf der rechten Seite verlassen ihren Partner und vollziehen miteinander einen Right
Arm Turn, einmal komplett herum und enden da, wo sie gestartet sind. Nach der Hälfte der Bewegung
nehmen sie ein Couple Handhold mit dem anderen Tänzer ein (d.h. mit dem, den sie ursprünglich direkt
angeschaut haben) und die zweite Hälfte des Arm Turns beendet jedes neue Couple, in dem es als eine Einheit
arbeitet.

Bei Reverse Flutterwheel vollzieht man die gleiche Tanzaktion, mit Ausnahme, dass die Tänzer auf der linken
Seite einen Left Arm Turn durchführen.

### Schlussformation

Facing Couples

### Timing

8 (SS All four ladies, 12 steps.)

### Styling

Jeder Tänzer, der an der Außenseite ist, bildet übergangslos ein neues Paar, indem er sich leicht neben
den ankommenden Tänzer dreht und mit ihm ein Couple Handhold bildet. Einige Tänzer beginnen, bevor es
zum Kontakt kommt, sich vorwärts zu bewegen und dann leicht vor ihrem neuen Partner vorauszugehen, so
dass die Bewegung insgesamt flüssiger wird.

Wenn die äußeren Tänzer Frauen sind, können sie ihre freie Hand für „Skirt Work“ nutzen.

### Bemerkungen

Beim Kommando „Ladies Lead, Flutterwheel“ ändern die zusätzlichen Worte nichts an der
Tanzaktion, sondern sollen nur hilfreich sein. Jedoch können sie in einigen Regionen zu Verwirrungen führen,
da die Tänzer ein „Ladies Lead Dixie Style to a Wave“ erwarten.

Aus einem Squared Set, für „All 4 Women Lead, Flutterwheel“ oder „Everyone Reverse The Flutter“ siehe den
Abschnitt „Zusätzliche Angaben: Erweiterungen wie Reverse Wheel Around".

###### @ Copyright 1994, 2000-2017 by CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
