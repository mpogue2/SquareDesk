
# Touch a Quarter

### Starting formation

Facing Dancers only

### Command Examples

#### Touch A Quarter
#### Touch One Quarter

### Dance action

In one smooth motion, Step To A Wave and Turn 1/4 By The Right

### Ending formation

Right-Hand Mini-Wave

### Timing

2

### Styling

Hands Up (see Additional Detail: Styling: Arms and Hands). 
When called from Facing Couples, the four dancers do not make a Wave midway through Touch 1/4.

From Facing Dancers, the call [Step To A Wave](ocean_wave.md) gives a Right-Hand Mini-Wave.

The [Ocean Wave Rule](../b2/ocean_wave_rule.md) does not apply to this call. Therefore, a combination like
"Swing Thru, All 8 Circulate, Touch 1/4" is improper.

The left-handed version of this call is Left Touch 1/4. See "Additional Detail: Commands: Extensions like Reverse Wheel Around".

###### @ Copyright 1994, 2000-2021 by CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
