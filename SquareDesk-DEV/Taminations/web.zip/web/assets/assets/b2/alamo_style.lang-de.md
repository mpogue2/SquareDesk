
# Alamo Style

### Startformation

Dieselbe wie für [Allemande Left](../b1/allemande.md)

### Kommandobeispiele

#### Allemande Left In The Alamo Style
#### Allemande Left In Alamo Style and Balance
#### Allemande Left In The Alamo Style, Right To Partner And Balance Awhile

### Tanzaktion

Die Tänzer beginnen mit einem Allemande Left, aber drehen den Arm Turn solange weiter, bis die
Männer zur Mitte des Squares und die Frauen aus dem Square herausschauen. Die linke Handverbindung
wird beibehalten und mit der rechten geht man eine Verbindung mit dem benachbarten Tänzer ein, um einen
Alamo Ring zu bilden.

### Schlussformation

Alamo Ring

### Timing

4

### Styling

Beide Hände werden gleichzeitig nach oben gebracht, dabei gleitet man sanft aus der
Unterarmverbindung des Allemande Left, zu einer Handhaltung wie bei einem Step to a Wave

###### @ Copyright 1994, 2000-2017 by CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.