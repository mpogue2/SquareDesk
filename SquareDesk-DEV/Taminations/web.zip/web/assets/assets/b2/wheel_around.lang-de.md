
# Wheel Around

### Startformation

Couple

### Kommandobeispiele

#### Promenade, Keep Walking; Heads Wheel Around and make lines
#### Promenade, Keep Walking; Sides Wheel Around; Right and Left Thru
#### Promenade; All Wheel Around; Promenade, Wrong Way
#### Pass Thru; Wheel Around (from Facing Couples)
#### Heads Pass Thru and Wheel Around; those Ladies Chain
#### Pass Thru; Wheel and Deal; Centers Wheel Around
#### Heads Slide Thru and Square Thru 3; Left Touch 1/4; Walk and Dodge; Wheel Around
#### Sides Star Thru; Double Pass Thru; Centers In; Boys Wheel Around; Couples Circulate

### Tanzaktion

Das Paar dreht sich als Einheit nach links um (180°). Der Tänzer links geht rückwärts, der Tänzer
rechts geht vorwärts. Der Drehpunkt ist die Handverbindung zwischen den Tänzern.

### Schlussformation

Couple

### Timing

4

### Styling

Die Tänzer haben Couple Handhold oder behalten die Handhaltung des vorhergehenden Calls bei (z.B.
Promenade). Die Handhaltung wird am Ende von Wheel Around, wenn notwendig, an den nächsten Call
angepasst.

### Bemerkungen

Promenieren vier Paare und zwei davon sollen einen Wheel Around ausführen, dann sind weitere
Aktionen notwendig. Zum Beispiel bei "Promenade, Keep Walking; Heads Wheel Around" bleiben die Sides
stehen, während die Heads Wheel Around ausführen. Danach richten sich alle zu Facing Lines aus. Einige
Caller unterrichten, dass die Sides das Promenieren beenden, wenn sie eine Head- oder Side-Wand ansehen.
So ist die resultierende Formation ohne weitere Anpassungen ebenfalls parallel zu den Wänden ausgerichtet

Zu weiteren Informationen wie Tänzer für Wheel Around während einer Promenade angesprochen werden
können, siehe „Allgemeines: Wege, Tänzer zu benennen: Heads / Sides“.

Die Variante, bei der Tänzer sich in die andere Richtung drehen, heißt Reverse Wheel Around. Siehe
"Zusätzliche Angaben: Kommandos: Erweiterungen wie Reverse Wheel Around".

###### © 1994, 2000-2020 by CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed or revised in any derivation or publication.