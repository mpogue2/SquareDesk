
# Alamo Style

### Starting formation

Same as [Allemande Left](../b1/allemande.md)

### Command examples

#### Allemande Left In The Alamo Style
#### Allemande Left In Alamo Style and Balance
#### Allemande Left In The Alamo Style, Right To Partner And Balance Awhile

### Dance action

Dancers start an Allemande Left but continue the Arm Turn until the men are
looking toward the center of the square and the women are looking out.
Maintain the left handhold and join right hands with the adjacent dancer to form an Alamo Ring.

### Ending formation

Alamo Ring

### Timing

4

### Styling

Bring both hands up at the same time, sliding smoothly out of the forearm grip
of the Allemande Left, to blend into the same styling as Step to a Wave.

###### @ Copyright 1994, 2000-2021 by CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
