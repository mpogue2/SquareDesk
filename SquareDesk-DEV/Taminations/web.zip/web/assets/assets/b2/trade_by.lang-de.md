
# Trade By

### Startformation

Trade By

### Kommandobeispiele

#### Trade By

### Tanzaktion

Centers [Pass Thru](../b1/pass_thru.md), während die Outsides, die nach außen schauende Paare sein müssen, einen
[Partner Trade](trade.md) ausführen.

### Schlussformation

Eight Chain Thru

### Timing

4

### Styling

Wie bei [Pass Thru](../b1/pass_thru.md) und [Partner Trade](trade.md)

### Bemerkungen

Die [Ocean Wave Rule](../b2/ocean_wave_rule.md) gilt für die Tänzer im Center (z.B. aus einer 3/4 Tag Formation)

###### @ Copyright 1994, 2000-2017 by CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.