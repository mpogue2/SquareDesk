
# Box the Gnat

### Startformation

Facing Dancers, ein Mann und eine Frau

### Kommandobeispiele

#### Box The Gnat
#### Tag The Line, Face In; Box The Gnat; Right And Left Thru
#### Right And Left Grand; Box The Gnat; Wrong Way Grand
#### Right And Left Grand; Box The Gnat; Pull By; Left Allemande
#### Box The Gnat, Change Hands; Allemande Left
#### Heads Slide Thru and Box The Gnat; All Double Pass Thru
#### Swing thru, Box the Gnat, Right & Left Thru

### Tanzaktion

Die Tänzer geben sich die rechten Hände und heben diese zu einem Bogen an. Diese Handverbindung
bleibt während der gesamten Ausführung des Kommandos erhalten. In einer fließenden Bewegung gehen die
Tänzer aneinander vorbei und drehen sich dabei herum.

- Die Frau dreht sich nach links und geht unter den Bogen durch.
- Der Mann dreht sich nach rechts und läuft um die Frau herum.

Am Ende des Kommandos steht jeder Tänzer auf der Startposition des anderen und sie schauen sich wieder
an.

### Schlussformation

Facing Dancers

### Timing

4

### Styling

Die anfängliche Handverbindung ist wie beim Händeschütteln, allerdings liegen die Handinnenseiten
nicht ganz aufeinander. Während der Ausführung des Kommandos muss diese Handverbindung so angepasst
werden, dass die Tänzer am Ende wieder die gleiche Handverbindung haben. Dazu sollten die Hände leicht
übereinander gleiten, dabei aber trotzdem weiterhin einen gewissen Grad an Stabilität und Sicherheit bieten.

### Bemerkungen

Nach der Tanzaktion sind die rechten Hände weiterhin verbunden und sehr häufig beginnt das
nächste Kommando mit den bereits verbundenen Händen. Die [Ocean Wave Rule](../b2/ocean_wave_rule.md) gilt für diesen Call. Aus einer
Mini-Wave ändern die Tänzer ihre Handverbindung, so dass sie der oben beschriebenen entspricht. Abhängig
von der Handhaltung in einer Ocean Wave (diese kann regional unterschiedlich sein) müssen die Tänzer
anfangs etwas rückwärtsgehen.

###### © 1994, 2000-2020 by CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed or revised in any derivation or publication.