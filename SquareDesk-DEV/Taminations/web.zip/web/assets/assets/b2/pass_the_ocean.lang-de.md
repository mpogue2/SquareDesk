
# Pass the Ocean

### Startformation

Im Basic und Mainstream Programm nur Facing Couples

### Kommandobeispiele

#### Pass the Ocean

### Tanzaktion

Pass Thru; Face your Partner; Step To A Wave.

### Schlussformation

Right-Hand Ocean Wave

### Timing

4

### Styling

Die dreiteilige Definition wird in einer fließendenden Bewegung getanzt. Die linksstehenden Tänzer
gehen dabei vorwärts, in einem Bogen nach rechts, auf ihre Schlussposition. Die rechtsstehenden Tänzer
gehen vorwärts, geben sich die linken Hände (Hands-Up-Verbindungen) und führen einen 1/4 Arm Turn (90
Grad) miteinander aus.

### Bemerkungen

Die [Ocean Wave Rule](../b2/ocean_wave_rule.md) wird für dieses Kommando im Basic und Mainstream Programm nicht
angewendet. Sie kann aber in anderen Programmen angewendet werden.

Obwohl das Styling dazu auffordert, die Tanzaktion in einer fließendenden Bewegung zu tanzen, hat die
Definition von Pass the Ocean drei Teile und Caller können sich das für ihre Choreografien zu nutzen machen.

Das Kommando sollte aber im Basic und Mainstream Programm nicht aufgesplittet werden.

###### @ Copyright 1994, 2000-2017 by CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.