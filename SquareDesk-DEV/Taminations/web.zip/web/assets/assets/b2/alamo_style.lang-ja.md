
# Alamo Style (アラモ スタイル)

### 動作を始める隊形

[Allemande Left](../b1/allemande.md)（アレマンド レフト）に同じ。

### コール例

#### Allemande Left In The Alamo Style
#### Allemande Left In Alamo Style and Balance
#### Allemande Left In The Alamo Style, Right To Partner And Balance Awhile

### 動作

皆でAllemande Left (アレマンド レフト)を行うが、Arm Turn (アーム ターン)を男性がスクエアの中
心を、女性が外を向くまで続ける。 左手はそのまま維持し、右手は隣の人とつなぎ、Alamo Ring
(アラモ リング)を作る。

### 動作を終わる隊形

Alamo Ring (アラモ リング)

### タイミング

４拍。

### スタイリング

両手を同時に挙げ、前腕を取っているAllemande Left (アレマンド レフト)から滑らかに、Step To A
Wave (ステップ トゥー ア ウエイブ)のスタイリングで、Alamo Ring (アラモ リング)に移行する。

###### @ 版権 1994, 2000-2017 CALLERLAB、スクエアダンスコーラー国際協会。 再印刷、再発行、使用料の 発生しない写物製作はこの文章表示を条件にこれを許可する。 使用料の発生しないインターネットでの刊行 はこの文章表示を条件にこれを許可する。 使用料の発生しない一部または全ての引用はこの文章表示を条件 にこれを許可する。 いかなる写物製作または刊行においても本書内の資料は変更されまた改訂されてはなら ない。


