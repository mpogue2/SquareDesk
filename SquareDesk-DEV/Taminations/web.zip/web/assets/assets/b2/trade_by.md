
# Trade By

### Starting formation

Trade By

### Command examples

Trade By

### Dance Action

Centers Pass Thru while Outsides, who must be Couples facing out, Partner Trade

### Ending formation

Eight Chain Thru

### Timing

4

### Styling

Same as [Pass Thru](../b1/pass_thru.md) and [Partner Trade](trade.md).

### Comment

The [Ocean Wave Rule](../b2/ocean_wave_rule.md) applies to the center dancers (e.g., from a 3/4 Tag)

###### @ Copyright 1994, 2000-2021 by CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
