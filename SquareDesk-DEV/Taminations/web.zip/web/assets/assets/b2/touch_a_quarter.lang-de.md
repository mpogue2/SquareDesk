
# Touch 1/4

### Startformation

Nur Facing Dancers

### Kommandobeispiele

#### Touch A Quarter
#### Touch One Quarter

### Tanzaktion

In einer fließenden Bewegung, Step To a Wave und eine 1/4 Drehung um die gefassten rechten
Hände.

### Schlussformation

Right-Hand Mini-Wave

### Timing

2

### Styling

Hands Up-Verbindung (siehe "Zusätzliche Angaben: Styling: Arm- und Handhaltungen"). Wenn es aus
Facing Couples gecallt wird, gehen die 4 Tänzer, während sie den Touch 1/4 ausführen, zwischenzeitlich nicht
mit der mittleren Handverbindung in eine Wave.

### Bemerkungen

Aus Facing Dancers ergibt das Kommando Step To A Wave (#36a) eine Right-Hand Mini-Wave.
Die [Ocean Wave Rule](../b2/ocean_wave_rule.md) gilt für dieses Kommando nicht. Daher ist eine Kombination wie "Swing Thru, All 8
Circulate, Touch 1/4" unzulässig.

Eine linkshändige Version des Kommandos ist Left Touch 1/4. Siehe "Zusätzliche Angaben: Kommandos:
Erweiterungen wie Reverse Wheel Around".

###### @ Copyright 1994, 2000-2017 by CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
