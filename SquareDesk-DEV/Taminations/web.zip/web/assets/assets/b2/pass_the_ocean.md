
# Pass the Ocean

### Starting formation

Restricted at Basic and Mainstream to Facing Couples only

### Command example

#### Pass The Ocean

### Dance action

Pass Thru; Face your Partner; Step To A Wave

### Ending formation

Right-Hand Ocean Wave

### Timing

4

### Styling

The 3-part definition is smoothed out. The left-side dancers walk in a forward arc to the right to
their ending position. The right-side dancers walk forward to join left hands (hands up styling) and
turn 1/4 with each other.

### Comments

The application of the [Ocean Wave Rule](../b2/ocean_wave_rule.md) to this call is not used at Basic and Mainstream. It
may be applied in the other programs.

Even though the styling encourages a smoothed out dance action, the definition of Pass The Ocean has
three distinct parts and callers may take advantage of this in their choreography.

This call should not be fractionalized at Basic and Mainstream.

###### @ Copyright 1994, 2000-2021 by CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
