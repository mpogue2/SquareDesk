
# Press Ahead

From any appropriate formation: Those designated move
one dancer position forward.  Example: #1 Press Ahead:

> 
> ![alt](press-1.png)![alt](press-2.png)
>

Note: This is not the same as [Extend](../b2/extend.md).

###### @ Copyright 1983, 1986-1988, 1995-2024 Bill Davis, John Sybalsky and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
