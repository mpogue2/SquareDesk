
# Interlocked Diamond Formation

Two adjacent Diamonds in which the Very Centers work with the
furthest other 3 dancers.

> 
> ![alt](interlocked_diamonds_1.png)      
> 
> ![alt](interlocked_diamonds_2.png)  
> 

## Interlocked Diamond Circulate

Diamond Circulate to the next position in your Interlocked Diamond.

> 
> ![alt](interlocked_diamond_circulate_1a.png)
> ![alt](interlocked_diamond_circulate_1b.png)  
> 
> ![alt](interlocked_diamond_circulate_2a.png)
> ![alt](interlocked_diamond_circulate_2b.png)
> 

## Cut the Interlocked Diamond

From Interlocked Diamonds (Twin): The Points
[Cut the Diamond](../plus/cut_the_diamond.md), while the Centers
Interlocked Diamond Circulate.

>
> ![alt](cut_the_interlocked_diamond.png)
>

## Flip the Interlocked Diamond

From Interlocked Diamonds (Twin): The Points
[Flip the Diamond](../plus/flip_the_diamond.md), while the Centers
Interlocked Diamond Circulate.

>
> ![alt](flip_the_interlocked_diamond.png)
>

###### @ Copyright 1983, 1986-1988, 1995-2024 Bill Davis, John Sybalsky and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
