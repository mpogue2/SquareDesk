
# With the Flow

From Facing Couples, with each couple having sideways body flow--as a
couple--resulting from the previous call or with exactly one dancer in each
couple moving forward: This is a flowing 
[Walk and Dodge](../ms/walk_and_dodge.md). The leading dancer in
flow direction walks forward, as the other dancer dodges into the space being
vacated.

###### @ Copyright 1983, 1986-1988, 1995-2024 Bill Davis, John Sybalsky and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
