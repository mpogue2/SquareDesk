
# Cross Your Neighbor

From a Box Circulate: the Trailers [Cross Extend](cross_extend.md)
and Arm Turn 3/4 while the Leaders do your part of
[Follow Your Neighbor](../plus/follow_your_neighbor.md).
Cross Your Neighbor cannot be fractionalized.

From a Single 1/4 Tag: all dancers do the Trailers part
(Cross Extend and Arm Turn 3/4).

## Pass and Roll Your Cross Neighbor

From Single Eight Chain Thru: All Pass Thru. 
The Centers Turn Thru while the Outsides do a
right-face U-Turn Back. All begin a Pass Thru,
blending smoothly into Cross Your Neighbor
(equivalent to Pass Thru; Centers Left Touch 3/4 
while Outsides right-face U-Turn Back and
Roll). Ends in a Left-Hand Two-Faced Line.

Note: There is no consensus on the parts of this call or on 
how many parts it has. It does have a
definite first part (All Pass Thru), so 
“Finish Pass and Roll Your Cross Neighbor” is proper, but
fractionalizing this call or referring to any part 
except the first is not proper.

###### @ Copyright 1983, 1986-1988, 1995-2024 Bill Davis, John Sybalsky and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
