
# Relay the Shadow

From a Tidal Wave:
***All [Swing](../a2/slip.md)***.
***The Center six [Cast 3/4](../ms/cast_off_three_quarters.md),
while the Ends [Counter Rotate 1/4](../a2/box_counter_rotate.md),
meet the Very Centers,***
***Single [Hinge](../ms/hinge.md) &
[Spread](../plus/anything_and_spread.md).
The other four do the Centers' part
of a [Cast a Shadow](relay_the_shadow.md)*** (that is, Leaders "Shadow", Trailers
[Extend](../b2/extend.md), [Hinge](../ms/hinge.md), and
[Extend](../b2/extend.md)).

> 
> ![alt](relay_the_shadow.png)
> 

###### @ Copyright 1983, 1986-1988, 1995-2024 Bill Davis, John Sybalsky and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
