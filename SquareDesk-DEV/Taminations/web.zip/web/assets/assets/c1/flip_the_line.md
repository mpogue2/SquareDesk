
# Flip the Line (1/4, 1/2, 3/4, Full)

From a Wave only: Centers [Run](../b2/run.md) and all any-shoulder
[Tag the Line](../ms/tag.md) the given fraction (1/4, 1/2, 3/4, Full). 
"Any-shoulder" means: From a Right-Hand Wave, use a right
shoulder pass; from a Left-Hand Wave use a left shoulder
pass.

###### @ Copyright 1983, 1986-1988, 1995-2024 Bill Davis, John Sybalsky and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
