
# Zing

From a Box Circulate or Tandem Couples: Leaders Zoom but only turn
3/4 (270 degrees) as they go (similar to Quarter Out and Run). Trailers
Circulate and Quarter In. Zing is also proper from various 3-and-1 Boxes,
T-Bone Boxes, and from an isolated Tandem.

> 
> ![alt](zing_1.png)
> 

Points Zing:

> 
> ![alt](zing_2.png)
> 

###### @ Copyright 1983, 1986-1988, 1995-2024 Bill Davis, John Sybalsky and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
