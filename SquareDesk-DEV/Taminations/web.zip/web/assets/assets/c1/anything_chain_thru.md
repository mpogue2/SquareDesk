
# Diamond Chain Thru variation

## \<anything> Chain Thru

***All do the \<anything> call***, then
***the Very Centers [Trade](../b2/trade.md)***
and ***the Center Four [Cast Off 3/4](../ms/cast_off_three_quarters.md)***. 
If the \<anything> call is a Triangle or Diamond
Circulate, the word “Circulate” is conventionally omitted 
(for example, "Inpoint Triangle Chain Thru" or 
"Interlocked Diamond Chain Thru").

###### @ Copyright 1983, 1986-1988, 1995-2024 Bill Davis, John Sybalsky and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
