
# Percolate

From appropriate Parallel Waves or Lines, or Eight Chain
Thru formation:
***[Circulate](../b1/circulate.md)***;
***1/2 Circulate***;
***the Center 4 (those in the Wave)
[Hinge](../ms/hinge.md)
and [Cross](../a1/anything_and_cross.md)***
while ***the Ends [Turn Thru](../ms/turn_thru.md) 
or Left Turn Thru*** as appropriate. From
most places (for example, Parallel Waves) this ends in Lines Back-to-Back.
It can be done from anywhere the Circulate, 1/2 Circulate gives
a definite center Wave.

## Percolate But \<anything>

"Percolate But" means the Hinge and Cross is replaced by the "But" call.
The Ends complete the call as usual.

###### @ Copyright 1983, 1986-1988, 1995-2024 Bill Davis, John Sybalsky and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.

<!-- Parts
Percolate1
Percolate2
Percolate3
Percolate3
-->