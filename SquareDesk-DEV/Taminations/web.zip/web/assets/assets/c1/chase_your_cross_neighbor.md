# Chase Your Cross Neighbor

From Back-to-Back Couples only: 
In one smooth motion, Belles U-Turn Back to the right and all
Box Circulate; 
Cross Your Neighbor. 
Ends in a Left-Hand Two-Faced Line. This call feels like beginning a
[Chase Right](../plus/chase_right.md) and blending into a 
[Cross Your Neighbor](cross_your_neighbor.md).

###### @ Copyright 1983, 1986-1988, 1995-2024 Bill Davis, John Sybalsky and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.