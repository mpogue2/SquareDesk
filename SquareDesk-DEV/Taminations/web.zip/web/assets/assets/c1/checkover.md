
# Checkover

From Columns: The #1 and #2 dancers [Checkmate](../a2/checkmate.md) while
dancers #3 and #4 [Circulate](../b1/circulate.md), 
[Cast Off 3/4](../ms/cast_off_three_quarters.md), [Slither](../a2/slip.md), 
and [As Couples](../a1/as_couples.md) [Extend](../b2/extend.md).
Ends in Parallel Two-Faced Lines.

###### @ Copyright 1983, 1986-1988, 1995-2024 Bill Davis, John Sybalsky and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
