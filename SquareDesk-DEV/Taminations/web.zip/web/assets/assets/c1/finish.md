
# Finish

Do all but the first part of the call. Examples: "Finish a
[Motivate](../a2/motivate.md)",
"Finish a [Rotary Spin](rotary_spin.md)",
"Finish a [Pass and Roll](../a2/pass_and_roll.md)".

###### @ Copyright 1983, 1986-1988, 1995-2024 Bill Davis, John Sybalsky and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
