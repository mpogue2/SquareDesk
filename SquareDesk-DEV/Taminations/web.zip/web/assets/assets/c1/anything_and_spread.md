
# (Anything) and Spread

In addition to the three ways [Spread](../plus/anything_and_spread.md) is used at
Plus, there is a fourth way:

If specific dancers are directed to Spread 
(for example, "Everyone Trade, Boys Spread"),
they slide away from the adjacent dancer one position. The
inactive dancers do not move. This can be used to create an Hourglass
(From #0 Lines: "Touch 1/4, Column Circulate 1 1/2, Center 6 Trade, Girls
Spread"), Blocks (From #0 Lines: "Touch 1/4, Boys Spread, Check Blocks"),
or other formations.

###### @ Copyright 1983, 1986-1988, 1995-2024 Bill Davis, John Sybalsky and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
