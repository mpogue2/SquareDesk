
# Tandem Concept

Similar to the "As Couples" concept, but the two dancers
that work as a unit are a Tandem. Nobody ever comes
between the dancers in a tandem. For example, 
"Tandem [Swing Thru](../b2/swing_thru.md)":

> 
> ![alt](tandem_concept_1a.png)
> ![alt](tandem_concept_1b.png)
> ![alt](tandem_concept_1c.png)
> 

or "Tandem [Quarter Thru](../a1/quarter_thru.md)":

> 
> ![alt](tandem_concept_2a.png)
> ![alt](tandem_concept_2b.png)
> ![alt](tandem_concept_2c.png)
> 

Common applications include Touch 1/4, Hinge, Scoot Back, Swing Thru, Walk and Dodge.

###### @ Copyright 1983, 1986-1988, 1995-2024 Bill Davis, John Sybalsky and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
