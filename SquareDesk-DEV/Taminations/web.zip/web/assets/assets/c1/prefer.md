
# Prefer

Used to designate a dancer or dancers different from those specified
in the definition. Two common uses are: from General Lines with men
facing on the ends, "Prefer the Head Men, In Roll Circulate". From a
General Line with the men and at least one woman facing the same way,
"Prefer the Men, Explode the Line" (i.e., the men step forward and all
face and Pull By).

###### @ Copyright 1983, 1986-1988, 1995-2024 Bill Davis, John Sybalsky and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
