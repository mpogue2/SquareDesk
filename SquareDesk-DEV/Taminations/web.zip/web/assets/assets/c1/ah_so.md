
# Ah So

From a Wave or Line: With each half of the Wave or Line 
working as a unit, the Ends
[Cross Fold](../ms/fold.md) and the Centers
follow along so as to keep each Mini-Wave or Couple intact. 
If the Ends start out facing the same way, they pass right
shoulders as they go.

> 
> ![alt](ah_so.png)
> 

*Teaching Hint:* This call is a more general version of
[Wheel and Deal](../b2/wheel_and_deal.md)—the
Centers are just turned around.

###### @ Copyright 1983, 1986-1988, 1995-2024 Bill Davis, John Sybalsky and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
