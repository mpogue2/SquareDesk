
# Switch to a Diamond

At Advanced,
[this call is done from a wave only](../a2/switch_to_a_diamond.md); at
C-1, it may start from a General Line. If the Ends are facing the same way
at the start, they meet with right hands, and adjust so the call ends in a
Diamond (rather than having the centers offset).

> 
> ![alt](switch_to_a_diamond_1a.png)
> ![alt](switch_to_a_diamond_1b.png)
> 

###### @ Copyright 1983, 1986-1988, 1995-2024 Bill Davis, John Sybalsky and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
