
# Ignore
 
1. Can be used to ask the dancers to use all the spots in the formation, but to have designated dancers not move while the others do the call. Example: "Ignore the head men, all Motivate". 
2. Can be used as an aid in identifying formations. Example: From Point-to-Point Diamonds, "Ignore the head men, Wave-Based Triangle Circulate". From Two-Faced Lines, "Ignore the lead end, Lines of 3, Out Roll Circulate". 
3. Has been used to ask that one or more dancers and their *spots* be eliminated while the others do the call. *This is considered incorrect usage.* Example: From Two-Faced Lines, "Ignore the trailing center, In Roll Circulate".

###### @ Copyright 1983, 1986-1988, 1995-2024 Bill Davis, John Sybalsky and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
