
# Switch the Line

From a General Line: Centers [Run](../b2/run.md), while the Ends
[Cross Run](../b2/run.md). In cases where dancers would collide, those doing the
Cross Run move outside of those doing the Run; otherwise,
all the usual shoulder passing rules apply.

> 
> ![alt](switch_the_line.png)
> 

###### @ Copyright 1983, 1986-1988, 1995-2024 Bill Davis, John Sybalsky and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
