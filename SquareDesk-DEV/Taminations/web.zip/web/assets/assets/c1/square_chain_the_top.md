
# Square Chain the Top

From Facing Couples:
***Right [Pull By](../b1/pull_by.md) and
[Quarter In](../a1/quarter_in.md);***
***Left [Spin The Top](../ms/spin_the_top.md);***
***Left [Turn Thru](../ms/turn_thru.md)***.
Ends in Back-to-Back Couples.

###### @ Copyright 1983, 1986-1988, 1995-2024 Bill Davis, John Sybalsky and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
