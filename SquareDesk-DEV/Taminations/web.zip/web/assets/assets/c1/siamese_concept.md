
# Siamese Concept

From a formation composed of 2 Tandems and 2 Couples:
Same as "In Tandem or As Couples": Those who are in the
Tandems work in Tandem, and those in the Couples work 
As Couples, and everyone does the 2-dancer or 4-dancer call specified.

###### @ Copyright 1983, 1986-1988, 1995-2024 Bill Davis, John Sybalsky and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
