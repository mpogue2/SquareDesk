
# Mini-Busy

Timing: 6

From Parallel Two-Faced Lines:
The trailers ***[As Couples](../a1/as_couples.md)
[Extend](../b2/extend.md)***,
have ***the center two
[Hinge](../ms/hinge.md)***,
and ***[Flip the Diamond](../plus/flip_the_diamond.md)***.
Meanwhile, the lead couples (working around the outside)
***Face In***,
***step forward one spot***,
and ***Face In***. Ends in a 1/4 Tag formation.
This call has three parts, as illustrated below:

> 
> ![alt](mini_busy_1a.png)![alt](mini_busy_1b.png)![alt](mini_busy_1c.png)![alt](mini_busy_1d.png)
> 

###### @ Copyright 1982, 1986-1988, 1995, 2001-2023. Bill Davis, John Sybalsky, and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.

<!-- Parts
MiniBusy1
MiniBusy2
MiniBusy3
MiniBusy1
MiniBusy2
MiniBusy3
-->