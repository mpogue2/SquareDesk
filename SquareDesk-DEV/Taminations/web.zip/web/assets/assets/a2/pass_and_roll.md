
# Pass and Roll

Timing: 10

From Single Eight Chain Thru: All [Pass Thru](../b1/pass_thru.md); the centers
[Turn Thru](../ms/turn_thru.md), while the outsides
do a right-face [U-Turn Back](../b1/turn_back.md). 
All [Pass Thru](../b1/pass_thru.md), and the centers 
[Pass Thru](../b1/pass_thru.md) as the outsides do a
[Right Roll to a Wave](../a1/right_roll_to_a_wave.md) to meet the centers. 
Ends in Parallel Mini-Waves.

> 
> ![alt](pass_and_roll_1a.png)![alt](pass_and_roll_1b.png)![alt](pass_and_roll_1c.png)![alt](pass_and_roll_1d.png)![alt](pass_and_roll_1e.png)
> 

###### @ Copyright 1982, 1986-1988, 1995, 2001-2023. Bill Davis, John Sybalsky, and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
