
# Scoot and Weave

Timing: 10

From Right-Hand (Left-Hand) Box Circulate formation:
***[Scoot Back](../ms/scoot_back.md)***.
***Those facing in Left (Right)
[Touch 1/4](../b2/touch_a_quarter.md)
with each other, while those facing out
[Quarter Right](../a1/quarter_in.md)
(Left)***. Ends in a Wave.

> 
> ![alt](scoot_and_weave_1a.png)![alt](scoot_and_weave_1b.png)![alt](scoot_and_weave_1c.png)
> 

From Single 1/4 Tag:
[Extend](../b2/extend.md),
[Trade](../b2/trade.md),
and then Weave the same way you would from Box Circulate formation.

> 
> ![alt](scoot_and_weave_2a.png)![alt](scoot_and_weave_2b.png)![alt](scoot_and_weave_2c.png)
> 

###### @ Copyright 1982, 1986-1988, 1995, 2001-2023. Bill Davis, John Sybalsky, and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
