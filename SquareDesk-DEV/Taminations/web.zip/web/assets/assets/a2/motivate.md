
# Motivate

Timing: 16

From Waves: ***All [Circulate](../b1/circulate.md),***
***the centers of each wave
[ Cast Off 3/4](../ms/cast_off_three_quarters.md)
while the ends [Circulate](../b1/circulate.md) 1/2, to create a star between two mini-waves.***
***The star turns half, while those in
the mini-waves [Trade](../b2/trade.md).***
***Those who meet
[Cast Off 3/4](../ms/cast_off_three_quarters.md),
while the others move up (as in [Chain Reaction](../a1/chain_reaction.md)) 
to become the ends of Parallel Waves.***

> 
> ![alt](motivate_1a.png)![alt](motivate_1b.png)![alt](motivate_1c.png)![alt](motivate_1d.png)![alt](motivate_1e.png)
> 

###### @ Copyright 1982, 1986-1988, 1995, 2001-2023. Bill Davis, John Sybalsky, and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
