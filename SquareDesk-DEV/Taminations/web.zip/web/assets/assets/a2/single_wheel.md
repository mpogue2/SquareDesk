
# Single Wheel

Timing: 4

From a Couple or Mini-Wave only: With each dancer taking the part of an entire couple,
do a [Wheel and Deal](../b2/wheel_and_deal.md). This call cannot be fractionalized.

For teaching: You can think of this as a [Hinge](../ms/hinge.md) and
[Roll](../plus/anything_and_roll.md). However, this call has only
one part—it cannot be fractionalized.

###### @ Copyright 1982, 1986-1988, 1995, 2001-2023. Bill Davis, John Sybalsky, and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
