
# Transfer and (Anything)

Timing: 8 (any starts on 5)

From Columns (or other applicable formation): The #1 and #2 dancers
[Transfer The Column](../a1/transfer_the_column.md), omitting
the final Extend, ending as an in-facing couple on the outside. The
other dancers walk forward to form a box (or other compact formation;
this may be less than a full circulate) in the center and do the
(Anything) call.

Example: Transfer and [ Quarter Thru](../a1/quarter_thru.md)

> 
> ![alt](transfer_and_anything_1a.png)![alt](transfer_and_anything_1b.png)![alt](transfer_and_anything_1c.png)
>

Example: Transfer and Crossfire

> 
> ![alt](transfer_and_anything_2a.png)![alt](transfer_and_anything_2b.png)![alt](transfer_and_anything_2c.png)
> 

Example: Transfer and Cut the Diamond

> 
> ![alt](transfer_and_anything_3a.png)![alt](transfer_and_anything_3b.png)![alt](transfer_and_anything_3c.png)
> 

Example: Transfer and Peel and Trail

> 
> ![alt](transfer_and_anything_4a.png)![alt](transfer_and_anything_4b.png)![alt](transfer_and_anything_4c.png)
> 

###### @ Copyright 1982, 1986-1988, 1995, 2001-2023. Bill Davis, John Sybalsky, and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
