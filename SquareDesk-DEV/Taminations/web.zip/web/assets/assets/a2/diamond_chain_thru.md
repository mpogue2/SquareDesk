
# Diamond Chain Thru

Timing: 10

From Diamonds:
***All [Diamond Circulate](../plus/diamond_circulate.md)***,
***the very centers [Trade](../b2/trade.md)***,
***and [Cast Off 3/4](../ms/cast_off_three_quarters.md) with the
adjacent ends of the wave***. Ends in Parallel Waves or Lines.

> 
> ![alt](diamond_chain_thru_1a.png)![alt](diamond_chain_thru_1b.png)  
> ![alt](diamond_chain_thru_1c.png)![alt](diamond_chain_thru_1d.png)
> 

###### @ Copyright 1982, 1986-1988, 1995, 2001-2023. Bill Davis, John Sybalsky, and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
