
# Switch to a Diamond / Hourglass

## Switch to a Diamond

Timing: 4

From a Wave or Line [*At Advanced, this call may be used from Waves only*]:
Centers [Run](../b2/run.md), while the ends do their part of 
[Diamond Circulate](../plus/diamond_circulate.md).

> 
> ![alt](switch_to_a_diamond_1a.png)![alt](switch_to_a_diamond_1b.png)
>

## Switch to an Hourglass

Timing: 4

From Waves or Lines [*At Advanced, this call may be used from parallel waves only*]:
Centers [Run](../b2/run.md), while the ends do their part of
[Hourglass Circulate](hourglass_circulate.md).

>
> ![alt](switch_to_an_hourglass_1a.png)![alt](switch_to_an_hourglass_1b.png)  
> ![alt](switch_to_an_hourglass_1c.png)![alt](switch_to_an_hourglass_1d.png)
>

###### @ Copyright 1982, 1986-1988, 1995, 2001-2023. Bill Davis, John Sybalsky, and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
