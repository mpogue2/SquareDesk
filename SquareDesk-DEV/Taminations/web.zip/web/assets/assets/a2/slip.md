
# Slip / Slide / Swing / Slither

## Slip

Timing: 3

From a General Line with the centers forming a Mini-Wave only: Centers Arm Turn 1/2 by
the hand they have joined.

## Slide

Timing: 3

From a General Line in which each end and the adjacent center form a Mini-Wave only:
Each end and the adjacent center slide nose-to-nose to take each other's place.

## Swing

Timing: 3

From a General Line with each end and the adjacent center in a Mini-Wave only: Each end
and the adjacent center Arm Turn 1/2 by the hand they have joined.

## Slither

Timing: 3

From a General Line with centers in a Mini-Wave only: The centers slide past each other
nose-to-nose, to take each other's place.

###### @ Copyright 1982, 1986-1988, 1995, 2001-2023. Bill Davis, John Sybalsky, and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
