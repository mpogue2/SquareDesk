
# Recycle

Timing: 6

From Facing Couples only: The beaus step forward until they are side-by-side, while
doing a [U-Turn Back](../b1/turn_back.md), turning toward each other. Meanwhile, the belles
[Veer Left](../b1/veer.md) and join
right hands with the original beaus. Ends in a Right-Hand Wave; the beaus finish as
centers of the Wave, and the belles finish as ends.

> 
> ![alt](recycle_1a.png)![alt](recycle_1b.png)
> 

###### @ Copyright 1982, 1986-1988, 1995, 2001-2023. Bill Davis, John Sybalsky, and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
