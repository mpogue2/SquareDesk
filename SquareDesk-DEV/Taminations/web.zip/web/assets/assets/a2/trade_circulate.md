
# Trade Circulate

Timing: 6

From Waves only: Leads [Trade](../b2/trade.md), while the trailing center
[Circulates](../b1/circulate.md) to the nearest end
of the other wave, and the trailing end [Circulates](../b1/circulate.md) 
to the nearest center of the other wave.

From Two-Faced Lines only: The Leads [Partner Trade](../b2/trade.md), 
while the trailers Diagonal [Pass Thru](../b1/pass_thru.md) with each other.

> 
> ![alt](trade_circulate_1a.png)![alt](trade_circulate_1b.png)  
> ![alt](trade_circulate_1c.png)![alt](trade_circulate_1d.png)
> 

Note: The Right-Shoulder Passing Rule applies to this call.

###### @ Copyright 1982, 1986-1988, 1995, 2001-2023. Bill Davis, John Sybalsky, and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
