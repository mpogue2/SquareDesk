
# Checkmate the Column

Timing: 10

From Columns: Numbers 1 and 2 in each column [Circulate](../b1/circulate.md) 4 spots and Face In, while
numbers 3 and 4 [Circulate](../b1/circulate.md) twice, Face In to form a couple,
then individually [Circulate](../b1/circulate.md). 
From Columns, ends in Parallel Two-Faced Lines.

> 
> ![alt](checkmate_1a.png)![alt](checkmate_1b.png)
> 
> ![alt](checkmate_2a.png)![alt](checkmate_2b.png)
>

###### @ Copyright 1982, 1986-1988, 1995, 2001-2023. Bill Davis, John Sybalsky, and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
