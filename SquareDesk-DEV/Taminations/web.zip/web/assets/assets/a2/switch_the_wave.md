
# Switch the Wave

Timing: 6

From a Wave: Centers [Run](../b2/run.md),
while the ends [Cross Run](../b2/run.md).

> 
> ![alt](switch_the_wave_1a.png)![alt](switch_the_wave_1b.png)  
> ![alt](switch_the_wave_1c.png)![alt](switch_the_wave_1d.png)
> 

###### @ Copyright 1982, 1986-1988, 1995, 2001-2023. Bill Davis, John Sybalsky, and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
