
# Pass and Roll Your Neighbor

Timing: 12

From Single Eight Chain Thru: All [Pass Thru](../b1/pass_thru.md). The centers
[Turn Thru](../ms/turn_thru.md) while the outsides
do a right-face [U-Turn Back](../b1/turn_back.md).
All begin a [Pass Thru](../b1/pass_thru.md), blending smoothly into
[Follow Your Neighbor](../plus/follow_your_neighbor.md)
(equivalent to Pass Thru; Centers Touch 3/4 while outsides right-face U-Turn Back and Roll).
Ends in a Left-Hand Wave.

> 
> ![alt](pass_and_roll_your_neighbor_1a.png)![alt](pass_and_roll_your_neighbor_1b.png)![alt](pass_and_roll_your_neighbor_1c.png)![alt](pass_and_roll_your_neighbor_1d.png)![alt](pass_and_roll_your_neighbor_1e.png)
> 

###### @ Copyright 1982, 1986-1988, 1995, 2001-2023. Bill Davis, John Sybalsky, and CALLERLAB Inc., The International Association of Square Dance Callers. Permission to reprint, republish, and create derivative works without royalty is hereby granted, provided this notice appears. Publication on the Internet of derivative works without royalty is hereby granted provided this notice appears. Permission to quote parts or all of this document without royalty is hereby granted, provided this notice is included. Information contained herein shall not be changed nor revised in any derivation or publication.
